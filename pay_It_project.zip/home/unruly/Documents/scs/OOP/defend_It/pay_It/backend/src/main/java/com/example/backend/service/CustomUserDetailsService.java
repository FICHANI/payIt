package com.example.backend.service;

import com.example.backend.model.Signup;
import com.example.backend.repository.SignupRepository;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final SignupRepository signupRepository;
    private static final Logger logger = LoggerFactory.getLogger(CustomUserDetailsService.class);

    public CustomUserDetailsService(SignupRepository signupRepository) {
        this.signupRepository = signupRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        logger.debug("Attempting to load user by email: {}", email);

        Signup user = signupRepository.findByEmail(email)
                .orElseThrow(() -> {
                    logger.warn("User not found with email: {}", email);
                    return new UsernameNotFoundException("User not found with email: " + email);
                });

        String role = "ROLE_" + user.getRole().toUpperCase();
        logger.debug("Found user: {} with role: {}", email, role);

        return new User(
                user.getEmail(),
                user.getPassword(), 
                Collections.singletonList(new SimpleGrantedAuthority(role))
        );
    }
}
