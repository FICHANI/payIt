package com.example.backend.controller;

import com.example.backend.model.Signup;
import java.util.Optional;
import com.example.backend.repository.SignupRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {

    private final SignupRepository signupRepository;

    public LoginController(SignupRepository signupRepository) {
        this.signupRepository = signupRepository;
    }

    // Show login page
    @GetMapping("/login")
    public String loginPage(Model model, HttpServletRequest request) {
        return "login";
    }

    // After login, redirect based on role
  @GetMapping("/default")
    public String defaultAfterLogin(Authentication authentication, HttpSession session) {
        // Handle case where authentication might be missing
        if (authentication == null || !authentication.isAuthenticated()) {
            return "redirect:/login?error=session_expired";
        }

        String email = authentication.getName(); // Principal email
        Optional<Signup> optionalUser = signupRepository.findByEmail(email);

        if (optionalUser.isPresent()) {
            Signup user = optionalUser.get();

            // Store user info in session attributes
            session.setAttribute("fullname", user.getFullname());
            session.setAttribute("email", user.getEmail());
            session.setAttribute("phone", user.getPhone());
            session.setAttribute("role", user.getRole());

            // Route by role
            if ("ROLE_ADMIN".equals(user.getRole())) {
                return "admin"; // This is a view name, admin.html
            } else {
                return "home"; // Regular user
            }
        }

        // Fallback if user not found in DB
        return "redirect:/login?error=user_not_found";
    }

    // Home page (GET /home)
    @GetMapping("/home")
    public String userHome(Model model, Authentication authentication) {
        /*if (authentication != null && authentication.isAuthenticated()) {
            String email = authentication.getName();
            Signup user = signupRepository.findByEmail(email).orElse(null);

            if (user != null) {
                model.addAttribute("fullname", user.getFullname());
                model.addAttribute("email", user.getEmail());
                model.addAttribute("phone", user.getPhone());
                model.addAttribute("role", user.getRole());
            }
        }
        */
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();
        Optional<Signup> userOpt = signupRepository.findByEmail(email);

        if (userOpt.isPresent()) {
            Signup user = userOpt.get();
            model.addAttribute("fullname", user.getFullname());
            model.addAttribute("email", user.getEmail());
            model.addAttribute("role", user.getRole());
        } else {
            model.addAttribute("fullname", "anonymous_user");
            model.addAttribute("role", "Hacker");
        }
        return "home";
    }

    // Logout
    @GetMapping("/logout")
    public String logoutPage(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        return "redirect:/login?logout=true";
    }
}
