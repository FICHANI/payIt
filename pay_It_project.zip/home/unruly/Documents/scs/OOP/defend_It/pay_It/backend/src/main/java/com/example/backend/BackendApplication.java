package com.example.backend;

import com.example.backend.model.User;
import com.example.backend.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class BackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(BackendApplication.class, args);
    }

@Bean
CommandLineRunner init(UserRepository userRepository) {
    return args -> {
        System.out.println("Initializing users...");
        if (userRepository.count() == 0) {
            userRepository.save(new User("admin@example.com", "adminpass", "ADMIN"));
            userRepository.save(new User("user@example.com", "userpass", "USER"));
            System.out.println("Users initialized");
        } else {
            System.out.println("Users already exist");
        }
    };
}
}