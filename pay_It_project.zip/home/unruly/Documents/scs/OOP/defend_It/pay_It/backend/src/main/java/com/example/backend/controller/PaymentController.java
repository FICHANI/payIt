package com.example.backend.controller;

import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Controller
public class PaymentController {

    @PostMapping("/process-payment")
    public String processPayment(
            @RequestParam String recipient,
            @RequestParam double amount,
            @RequestParam String currency,
            Model model
    ) {
        // Validate currency input
        if (!currency.matches("USD|ZiG")) {
            model.addAttribute("error", "\u274C Unsupported currency: " + currency);
            return "home";
        }

        // Create mock API endpoint
        String apiUrl = "https://jsonplaceholder.typicode.com/posts"; // Fake endpoint for testing

        // Build request body
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("recipient", recipient);
        requestBody.put("amount", amount);
        requestBody.put("currency", currency);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);

        // Send POST request
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response;

        try {
            response = restTemplate.postForEntity(apiUrl, request, String.class);

            if (response.getStatusCode() == HttpStatus.CREATED || response.getStatusCode().is2xxSuccessful()) {
                model.addAttribute("recipient", recipient);
                model.addAttribute("amount", amount);
                model.addAttribute("currency", currency);
                model.addAttribute("timestamp", LocalDateTime.now());
                return "home"; 
            } else {
                model.addAttribute("error", "\u26A0\uFE0F Payment failed with status: " + response.getStatusCode());
                return "home";
            }
        } catch (Exception e) {
            model.addAttribute("error", "\u274C Could not connect to payment API: " + e.getMessage());
            return "home";
        }
    }
}
